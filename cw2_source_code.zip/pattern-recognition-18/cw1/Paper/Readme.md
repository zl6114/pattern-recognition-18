Paper to read
