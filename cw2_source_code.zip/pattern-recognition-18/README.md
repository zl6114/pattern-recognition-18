# Pattern Recognition
Coursework Repository with my teammate Aufar Laksana

### CW1:
Subspace Learning, foucsing on PCA, LDA

### CW2: 
Distance Metric Learning for Person re-id Problem